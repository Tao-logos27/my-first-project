// ---------- Data: one object per onboarding screen ----------
// layout "intro"  = wave illustration + chips   (steps 1 and 3)
// layout "detail" = dark illustration + cards   (step 2)
const steps = [
  {
    layout: "intro",
    tag: "Emotional Well-being",
    title: "Understand what you're feeling",
    text: "Take quick, science-backed check-ins at your own pace to track your emotional well-being safely and gently.",
    chips: [
      { icon: "🔒", label: "100% Confidential" },
      { icon: "⏱️", label: "2 Min Check-ins" },
      { icon: "🪷", label: "Zero Pressure" },
    ],
    cta: "Next",
    guest: "Or explore quietly as guest",
  },
  {
    layout: "detail",
    tag: "Secure & Confidential",
    tagIcon: "🛡️",
    title: "Verified, but never exposed",
    text: "Your name and phone number are only used to stop fake accounts — neither is ever shown to anyone. In discussions, you are only ever known by your chosen Anonymous Handle.",
    features: [
      { icon: "✔", title: "Private Anonymous Handle", desc: "Participate freely without carrying social stigma." },
      { icon: "🙈", title: "Zero Public Profile Data", desc: "Your contact details and search logs remain hidden." },
      { icon: "🌐", title: "Safe Cultural Sanctuary", desc: "A peaceful digital space designed for healing." },
    ],
    cta: "Next",
    guest: "Skip / Continue as guest",
  },
  {
    layout: "intro",
    tag: "Community & Stories",
    title: "You are not alone",
    text: "Read real stories from young people across Ethiopia and find support, hope and inspiration in a safe space.",
    chips: [
      { icon: "💬", label: "Real Stories" },
      { icon: "🤝", label: "Safe Community" },
      { icon: "✨", label: "Daily Inspiration" },
    ],
    cta: "Continue to Stories",
    guest: "Skip / Continue as guest",
  },
];

const TOTAL_STEPS = steps.length;
let current = 0;

// ---------- Elements ----------
const $ = (id) => document.getElementById(id);

const brandRow = $("brandRow");
const illus1 = $("illus1");
const illus2 = $("illus2");
const tagDot = $("tagDot");
const tagEmoji = $("tagEmoji");
const tagText = $("tagText");
const title = $("title");
const text = $("text");
const chips = $("chips");
const features = $("features");
const footer = $("footer");
const dots = $("dots");
const stepLabel = $("stepLabel");
const nextBtn = $("nextBtn");
const prevBtn = $("prevBtn");
const backBtn = $("backBtn");
const guestBtn = $("guestBtn");

// ---------- Render the current step ----------
function render() {
  const s = steps[current];
  const isDetail = s.layout === "detail";

  // show / hide the parts that change between layouts
  brandRow.classList.toggle("hidden", isDetail);
  illus1.classList.toggle("hidden", isDetail);
  illus2.classList.toggle("hidden", !isDetail);
  chips.classList.toggle("hidden", isDetail);
  features.classList.toggle("hidden", !isDetail);
  footer.classList.toggle("detail", isDetail);
  prevBtn.classList.toggle("hidden", current === 0);

  // tag (small pill above the title): dot or emoji icon
  tagText.textContent = s.tag;
  tagEmoji.textContent = s.tagIcon || "";
  tagDot.classList.toggle("hidden", Boolean(s.tagIcon));

  title.textContent = s.title;
  text.textContent = s.text;

  // chips (steps 1 and 3)
  chips.innerHTML = (s.chips || [])
    .map((c) => `<li><span>${c.icon}</span> ${c.label}</li>`)
    .join("");

  // feature cards (step 2)
  features.innerHTML = (s.features || [])
    .map(
      (f) => `
      <li>
        <span class="f-icon">${f.icon}</span>
        <div>
          <strong>${f.title}</strong>
          <p>${f.desc}</p>
        </div>
      </li>`
    )
    .join("");

  // progress dots + label
  dots.innerHTML = Array.from({ length: TOTAL_STEPS }, (_, i) =>
    `<span class="dot${i === current ? " active" : ""}"></span>`
  ).join("");
  stepLabel.textContent = `STEP ${current + 1} OF ${TOTAL_STEPS}`;

  nextBtn.textContent = s.cta + " →";
  guestBtn.textContent = s.guest;
}

function goNext() {
  if (current < steps.length - 1) {
    current++;
    render();
  } else {
    window.location.href = "stories.html";
  }
}

function goBack() {
  if (current > 0) {
    current--;
    render();
  } else {
    window.history.back(); // first step: go back to the welcome page
  }
}

function skip() {
  console.log("Skip → go to sign up / home");
  // window.location.href = "signup.html";
}

function continueAsGuest() {
  console.log("Guest mode → go to guest home");
  // window.location.href = "guest.html";
}

// ---------- Events ----------
nextBtn.addEventListener("click", goNext);
prevBtn.addEventListener("click", goBack);
backBtn.addEventListener("click", goBack);
guestBtn.addEventListener("click", continueAsGuest);
document.querySelectorAll(".skipBtn").forEach((b) => b.addEventListener("click", skip));

render();
