// Get Started button: go straight to the onboarding page.
// The links in index.html already point to onboarding.html,
// so no extra code is needed here. This file is kept for later features.
console.log("MindRise welcome page loaded");